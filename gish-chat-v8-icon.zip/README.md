# Gish Chat v8

نسخه اصلاح‌شده با ورود و ثبت‌نام با ایمیل.

## اجرا
```powershell
npm install
npm start
```
سپس `http://localhost:3000` را باز کنید.

حساب آزمایشی: `sara@gish.chat` / `123456`

نکته: برای امنیت واقعی، در محیط انتشار مقدار `JWT_SECRET` را تغییر دهید.
